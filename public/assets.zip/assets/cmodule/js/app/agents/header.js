(function () {
    var controlle_name = 'header-controller';
    modules.push(controlle_name);
    angular.module(controlle_name, []).controller("HeaderController", function ($scope, $http, $interval, $timeout, $window, Setting, $log) {
        
    });
})();